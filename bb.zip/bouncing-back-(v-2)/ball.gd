extends CharacterBody2D

const SPEED := 10.0

signal out_of_bounds

func start():
	position = get_viewport_rect().size / 2

func _ready() -> void:
	velocity = Vector2(-SPEED, 0)
	start()

func _physics_process(delta: float) -> void:
	var col := move_and_collide(velocity)
	if col:
		var normal := col.get_normal()
		velocity = velocity.bounce(normal)
	if position.x < 0 or position.x > get_viewport_rect().size.x:
		out_of_bounds.emit()
		start()

func reset(reset_pos):
	global_position = reset_pos
	
