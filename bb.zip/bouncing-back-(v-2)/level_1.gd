extends Node2D
@onready var fade: CanvasLayer = $"."
@onready var color_rect: ColorRect = $ColorRect

var current_level : Node2D = null
var next_level = preload("res://world.tscn")

func _ready() -> void:
	current_level = $"."
	var exit = current_level.get_node("Exit")
	exit.body_entered.connect(_exit_level)

func _exit_level(body) -> void:
	if body.name == "player":
		print("level complete")
		await fade.fade(1.0, 1.5).finished
		print("faded out")
		current_level.queue_free()
		var new_level = next_level.instantiate()
		add_child(new_level)
		await fade.fade(0.0, 1.5).finished
		print("faded in")
