extends CharacterBody2D

const SPEED := 400.0

func getydir() -> float:
	return Input.get_action_strength("downarrow") - Input.get_action_strength("uparrow")

func _physics_process(delta: float) -> void:
	var dir :Vector2=Vector2(0, getydir())
	velocity = dir * SPEED
	move_and_slide()
