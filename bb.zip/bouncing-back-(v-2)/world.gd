extends Node2D

@onready var Ball = $"../Ball"

@onready var detector_left = $DetectorLeft
@onready var detector_right = $DetectorRight

var game_area_size = Vector2(1200, 720)

func _ready():
	detector_left.ball_out.connect(_on_detector_ball_out)
	detector_right.ball_out.connect(_on_detector_ball_out)
	
	reset_game()

func reset_game():
	
	reset_round()

func reset_round():
	var reset_pos = game_area_size / 2.0
	Ball.reset(reset_pos)

func _on_detector_ball_out(is_left):
	reset_round()
